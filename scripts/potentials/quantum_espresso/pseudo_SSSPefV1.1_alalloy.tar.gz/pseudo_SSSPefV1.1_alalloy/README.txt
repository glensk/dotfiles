This is the same as the SSSPefficiency v1.1 family with the following difference:

Cu_pbe_v1.2.uspp.F.UPF -> Cu.pbe-dn-kjpaw_psl.1.0.0.UPF 
